package com.example.agnesmalumeventtrackingapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EventActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private EditText eventNameText;
    private EditText eventDateText;
    private EditText eventTimeText;
    private LinearLayout eventsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this, "EVENT ACTIVITY OPENED", Toast.LENGTH_LONG).show();
        setContentView(R.layout.activity_event);

        databaseHelper = new DatabaseHelper(this);

        eventNameText = findViewById(R.id.eventNameText);
        eventDateText = findViewById(R.id.eventDateText);
        eventTimeText = findViewById(R.id.eventTimeText);
        Button addEventButton = findViewById(R.id.addEventButton);
        eventsContainer = findViewById(R.id.eventsContainer);

         displayEvents();

        addEventButton.setOnClickListener(v -> {

            String eventName = eventNameText.getText().toString().trim();
            String eventDate = eventDateText.getText().toString().trim();
            String eventTime = eventTimeText.getText().toString().trim();

            if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
                Toast.makeText(
                        EventActivity.this,
                        "Please enter all event information",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean added = databaseHelper.addEvent(
                    eventName,
                    eventDate,
                    eventTime
            );

            if (added) {
                Toast.makeText(
                        EventActivity.this,
                        "Event added successfully",
                        Toast.LENGTH_SHORT
                ).show();

                eventNameText.setText("");
                eventDateText.setText("");
                eventTimeText.setText("");

                displayEvents();

            } else {
                Toast.makeText(
                        EventActivity.this,
                        "Unable to add event",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    private void displayEvents() {

        eventsContainer.removeAllViews();

        Cursor cursor = databaseHelper.getAllEvents();

        while (cursor.moveToNext()) {

            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(
                    cursor.getColumnIndexOrThrow("eventName")
            );
            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow("eventDate")
            );
            String time = cursor.getString(
                    cursor.getColumnIndexOrThrow("eventTime")
            );

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            TextView eventText = new TextView(this);

            eventText.setText(
                    name + " | " + date + " | " + time
            );

            eventText.setLayoutParams(
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1
                    )
            );

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");

            deleteButton.setOnClickListener(v -> {

                boolean deleted = databaseHelper.deleteEvent(id);

                if (deleted) {
                    Toast.makeText(
                            EventActivity.this,
                            "Event deleted",
                            Toast.LENGTH_SHORT
                    ).show();

                    displayEvents();
                }
            });

            row.addView(eventText);
            row.addView(deleteButton);

            eventsContainer.addView(row);
        }

        cursor.close();
    }
}